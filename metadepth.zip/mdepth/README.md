# MetaDepth Package

A very rudamentary package for the Atom text editor that enables syntax highlighting for both *metaDepth* as well as *EOL*.

**Author:** Randy Paredis <randy.paredis@uantwerpen.be>

## Installation:
Open Atom and select `File > Settings > Open Config Editor`. This opens Atom's config directory. You have to extract the contents of this archive under the `packages` folder.
